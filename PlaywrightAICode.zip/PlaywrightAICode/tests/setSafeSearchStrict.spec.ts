import { test, expect } from '@playwright/test';

test('Set SafeSearch to Strict on Bing', async ({ page }) => {
  // Navigate to Bing SafeSearch settings
  await page.goto('https://www.bing.com/account/general?ru=');

  // Select the "Strict" radio button in the SafeSearch section
  await page.check('input[name="adlt_set"]');

  // Wait for 10 seconds
  await page.waitForTimeout(10000);

  // Close the browser
  await page.close();
});
