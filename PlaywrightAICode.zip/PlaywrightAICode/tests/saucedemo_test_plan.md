# Test Plan: SauceDemo - Login, Add Product to Cart, and Logout

## Test Case ID: TC001

### Objective
Verify the user can log in with valid credentials, add the first product to the cart, and log out successfully.

---

### Pre-conditions
1. The user has valid login credentials.
2. The browser is installed and functional.

---

### Test Steps
1. **Navigate to SauceDemo:**
   - Open the browser.
   - Navigate to `https://www.saucedemo.com`.

2. **Login with Valid Credentials:**
   - Enter the username in the "Username" field (e.g., `standard_user`).
   - Enter the password in the "Password" field (e.g., `secret_sauce`).
   - Click the "Login" button.

3. **Add the First Product to the Cart:**
   - On the products page, locate the first product.
   - Click the "Add to Cart" button for the first product.

4. **Verify Product in Cart:**
   - Click the cart icon in the header.
   - Verify the first product is listed in the cart.

5. **Logout:**
   - Click the menu icon in the top-left corner.
   - Select the "Logout" option.

---

### Expected Results
1. The user is successfully logged in and redirected to the products page.
2. The first product is successfully added to the cart.
3. The product is visible in the cart.
4. The user is successfully logged out and redirected to the login page.

---

### Post-conditions
1. The browser is closed.
2. The cart is cleared after logout.
