import { test, expect } from '@playwright/test';

test('Login with Valid Credentials', async ({ page }) => {
  // Navigate to SauceDemo
  await page.goto('https://www.saucedemo.com');

  // Enter the username in the "Username" field
  await page.fill('#user-name', 'standard_user');

  // Enter the password in the "Password" field
  await page.fill('#password', 'secret_sauce');

  // Click the "Login" button
  await page.click('#login-button');

  // Verify the user is redirected to the products page
  await expect(page).toHaveURL(/inventory\.html/);

  // Close the browser
  await page.close();
});