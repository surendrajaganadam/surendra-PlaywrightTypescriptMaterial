import { test, expect } from '@playwright/test';

test('Verify Bing title', async ({ page }) => {
  // Navigate to Bing
  await page.goto('https://www.bing.com');

  // Verify the title of the webpage
  await expect(page).toHaveTitle('Search - Microsoft Bing');

  // Close the browser
  await page.close();
});
