import { test, expect } from '@playwright/test';

test('Login to SauceDemo', async ({ page }) => {
  // Navigate to SauceDemo
  await page.goto('https://www.saucedemo.com');

  // Enter username
  await page.fill('#user-name', 'standard_user');

  // Enter password
  await page.fill('#password', 'secret_sauce');

  // Click on login button
  await page.click('#login-button');

  // Wait for 10 seconds
  await page.waitForTimeout(10000);

  // Close the browser
  await page.close();
});
