import { test, expect } from '@playwright/test';

test('Navigate to HDFC Blogs and Search', async ({ page, context }) => {
  // Navigate to HDFC homepage
  await page.goto('https://www.hdfc.com/');

  // Click on the Blogs link in the header
  const [newPage] = await Promise.all([
    context.waitForEvent('page'),
    page.click('text=Blogs') // Adjust the selector if necessary
  ]);

  // Wait for the new page to load
  await newPage.waitForLoadState();

  // Handle the Disclaimer popup by clicking the CONTINUE button
  await newPage.click('text=CONTINUE'); // Adjust the selector if necessary

  // Click on the Search button in the header
  await newPage.click('text=Search'); // Adjust the selector if necessary

  // Wait for 10 seconds
  await newPage.waitForTimeout(10000);

  // Close the browser
  await newPage.close();
});
