let array1: number[] = [501,601,701];
let array2: number[] = [102,202,902];
let array3: number[] = array1.concat(array2);
/*
differnt ways to define an array*/
let array4: Array<number> = [1001, 2001, 3001];

let array5: number[] = new Array(4001, 5001, 6001);

let array6: number[] = new Array(3); // creates an array of length 3 with all elements as undefined



// console.log("concatenated array:", array3);

// console.log("convert array to string:", array3.toString());

// console.log("index of 202:", array3.indexOf(202));
// console.log("find example :" , array3.find((value)=> value > 600));

// console.log("check for includes 701:", array3.includes(701));
// console.log("check for includes 9001:", array3.includes(9001));

// console.log("sorted order is :" , array3.sort((a,b)=> a-b)); // ascending order
// console.log("sorted order is :" , array3.sort((a,b)=> b-a)); // descending order

// console.log("sliced arrta is: ", array3.slice(3,5)); 

//i want to remove 2 elementnets starting from undex 2 and add 1 , 2
array3.splice(2,2,1,2);
console.log("after splice array is :", array3);
