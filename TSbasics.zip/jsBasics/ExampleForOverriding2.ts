class carOnRoadPrice{
price:number =100000;

constructor(){
console.log("carOnRoadPrice constructor called");
}

printPrice():void{
console.log("The price of car on road is "+this.price);

}

}

class hydOnroadPrice extends carOnRoadPrice{
discount:number = 5000;

constructor(){
super();
console.log("hydOnroadPrice constructor called");
}

printPrice():void{
console.log(super.printPrice());
console.log(this.discount);

}

}

let hydInstance = new hydOnroadPrice();
hydInstance.printPrice();
