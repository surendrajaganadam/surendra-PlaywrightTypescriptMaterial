/*
Array --> group of similar data types
i know how to define a single sting 
but how can we define multiple strings
syntax:
let nameArray: string[] = ['name1', 'name2', 'name3'];
let idArray: number[] = [1, 2, 3, 4, 5];
let booleanArray: boolean[] = [true, false, true];

elements in the array can be accessed using index
index starts from 0
nameArray[0] --> 'John'
nameArray[1] --> 'Jane'
nameArray[2] --> 'Doe'

*/

let nameArray: string[] = ['John', 'Jane', 'Doe'];
// console.log('Name Array:', nameArray);

//i want to print 2nd element from the array
// console.log('2nd Element:', nameArray[1]);

// for(let i:number=0; i<nameArray.length; i++){
//     console.log(`Element at index ${i}:`, nameArray[i]);
// }


// nameArray.push('Smith'); // adds 'Smith' to the end of the array
// console.log('After Push:', nameArray);

// nameArray.unshift('Ramya'); // adds 'Ramya' to the beginning of the array
// console.log('After Unshift:', nameArray);

// nameArray.pop();    // removes the last element from the array
// console.log('After Pop:', nameArray);

// nameArray.shift();  // removes the first element from the array
// console.log('After Shift:', nameArray);

nameArray[1] = 'Surendra'; // updates the 2nd element to 'Alice'
console.log('After Update:', nameArray);