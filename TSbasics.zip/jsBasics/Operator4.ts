let isLoggedInUser: boolean = true;
let isAdminUser: boolean = false;

// console.log("verifying && operator : " + isLoggedInUser && isAdminUser);
// console.log("verifying && operator : " + isLoggedInUser || isAdminUser);
console.log("verifying ! operator : " + !isLoggedInUser);
