// let studentDetails: [number, string] = [1, "John"];
// console.log(studentDetails);
// console.log(studentDetails[0]); // 1
// console.log(studentDetails[1]); // John

let studentDetails: [number, number] = [1, 100];
// console.log(studentDetails);
// console.log(studentDetails[0]); // 1
// console.log(studentDetails[1]); // John

// studentDetails[1] = 200; // valid
studentDetails= [2, 300]; // valid
console.log(studentDetails);