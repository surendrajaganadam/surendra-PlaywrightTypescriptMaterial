/*let i:number = 1;

for(i; i<=10; i++){
    console.log("value of i: " + i);
} 


for(let i:number = 1; i<=10; i++){
    console.log("value of i: " + i);
}*/

// if number % 2 == 0 --> even number
// if number % 2 != 0 --> odd number
//below logic will print even number between 0 to 20
// for(let i:number = 0; i<=20; i++){
//     if(i % 2 == 0){
//         console.log("Even number: " + i);
//     }
// }

//print odd number between 0 to 20
// for(let i:number = 1; i<=20; i++){
//     if(i % 2 != 0){
//         console.log("Odd number: " + i);
//     }
// }

//I want to print numbers from 1 to 100 but if 5 is there then break the loop

for(let i:number = 1; i<=100; i++){
    console.log("value of i: " + i);
    if(i == 5){
        console.log("Breaking the loop");
        break;
    }
}
