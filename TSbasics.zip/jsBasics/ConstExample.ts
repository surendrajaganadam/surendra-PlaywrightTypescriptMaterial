const salary: number = 50000;
console.log("Salary: " + salary);

// salary = 60000; // This will cause a compile-time error


// const empAge: number;
// number = 30; // This will cause a compile-time error