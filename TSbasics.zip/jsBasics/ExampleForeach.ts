let names: string[] = ["John", "Smith", "Mary"];
/*
foreach loop will work for each n every element in the array
we no need to define increment or decrement for that 
automatically it will take care of that
*/
// for(let name of names){
//     console.log(name);
// }

names.forEach((name)=>{
    console.log(name);
})