let inputValue: number = 20;
/*
inputValue += 100; // inputValue = inputValue + 100
console.log("inputValue after += : " + inputValue);



inputValue -= 10; // inputValue = inputValue - 10
console.log("inputValue after -= : " + inputValue);



inputValue *= 5; // inputValue = inputValue * 5
console.log("inputValue after *= : " + inputValue);



inputValue /= 2; // inputValue = inputValue / 2
console.log("inputValue after /= : " + inputValue);
*/

inputValue %= 2; // inputValue = inputValue % 2
console.log("inputValue after %= : " + inputValue);