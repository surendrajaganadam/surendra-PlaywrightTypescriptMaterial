import {greetingMessage1, greetUser, DemoClassInformation} from './ExampleForModule1';
console.log(greetingMessage1);
greetUser();
let demoClass = new DemoClassInformation();