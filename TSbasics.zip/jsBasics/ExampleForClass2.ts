class studenInfo3{

constructor(){
console.log("This is constructor");
}

displayData(): void{
console.log("This is a displaymethod ");
}


}

let data3 = new studenInfo3();
data3.displayData();
/*new keyword will create the object for that class
which means it will allocate some memory for that class
with that referemce we can access the method & properties present with that class
using this new keyword we can creater multiple obejcts tot he same class
it will also invoke the code present in the cosntructor
*/