let i: number = 0;

// while(i <= 10) {
//     console.log("value of i: " + i);
//     i++;
// }

// while(i <=20) {
//     if(i % 2 == 0) {
//         console.log("Even number: " + i);
//     }
//     i++;
// }


// while(i <=20) {
//     if(i % 2 != 0) {
//         console.log("odd number: " + i);
//     }
//     i++;
// }


// while(i <= 10) {
//     console.log("value of i: " + i);
//     if(i == 5) {
//         console.log("Breaking the loop");
//         break;
//     }
//     i++;
// }

//continue statement: skips the current iteration of the loop and moves to the next iteration 

// for(let i:number = 1; i<=10; i++){
//     if(i == 5 || i == 7 || i == 9){
//         console.log("Skipping the iteration for i: " + i);
//         continue;
//     }
//     console.log("value of i: " + i);
// }

let j: number = 1;
while(j <= 10) {
    if(j == 5 || j == 7 || j == 9) {
        console.log("Skipping the iteration for j: " + j);
        j++;
        continue;
    }
    console.log("value of j: " + j);
    j++;
}