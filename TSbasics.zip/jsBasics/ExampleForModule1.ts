export let greetingMessage1:string = "Hello, welcome to the module system!";

export function greetUser(): void{
console.log("heloo eervyone Good Morning")
}

export class DemoClassInformation{
constructor(){
    console.log("This is a demo class")
}
}

