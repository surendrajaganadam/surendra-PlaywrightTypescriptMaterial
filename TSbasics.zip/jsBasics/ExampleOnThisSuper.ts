class DemoPrice{
priceValue: number = 1000;

constructor(){
console.log("parent class constructor called");
}

showPrice():void{
console.log("The price is: " + this.priceValue);
}

}


class DemoDiscount extends DemoPrice{
discountValue: number = 100;

constructor(){
super();  // it will call parent class constructor
console.log("child class constructor called");
}

showDiscount():void{
console.log("The discount is: " + this.discountValue);

super.showPrice(); // accessing parent class method using super keyword

}

}

let discountInstance = new DemoDiscount();
discountInstance.showDiscount();