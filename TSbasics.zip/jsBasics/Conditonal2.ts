let firstNumber:number = 100;
let secondNumber:number = 20;
let thirdNumber:number = 30;

/*
i want to identify bigger number: 
1st number > 2nd number & also 1 number > 3rd numer --> 1st number is bigger



if(firstNumber > secondNumber && firstNumber > thirdNumber){
    console.log("First number is bigger");
}else if(secondNumber > firstNumber && secondNumber > thirdNumber){
    console.log("Second number is bigger");
}else{
    console.log("Third number is bigger");
}
*/

if(firstNumber > secondNumber && firstNumber > thirdNumber)
    console.log("First number is bigger");
else if(secondNumber > firstNumber && secondNumber > thirdNumber)
    console.log("Second number is bigger");
else
    console.log("Third number is bigger");
