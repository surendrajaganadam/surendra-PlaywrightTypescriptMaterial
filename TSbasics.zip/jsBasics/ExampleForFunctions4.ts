function greetingMessage(): string;
function greetingMessage(name: string): string;
function greetingMessage(name: string , age: number): string;


function greetingMessage(name?: string, age?: number): string {
if( typeof name === "string" && typeof age === "number"){
    return `Hello, ${name}! You are ${age} years old.`;
}else if(typeof name === "string"){
    return `Hello, ${name}!`;
}else{
    return "Hello, Guest!";
}
}

console.log(greetingMessage()); // Outputs: Hello, Guest!
console.log(greetingMessage("Alice")); // Outputs: Hello, Alice!
console.log(greetingMessage("Surendra", 30)); // Outputs: Hello, Surendra! You are 30 years old.
