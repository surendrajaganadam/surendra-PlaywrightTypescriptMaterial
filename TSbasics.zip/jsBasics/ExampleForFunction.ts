// function sum(){
//     console.log(2 + 3);
// }

// function sum(): void{
//     console.log(2 + 3);
// }

// function sum(): number{
//     return 2 + 3;
// }

/*
function name(para1, para2, ...): returnType{

}

*/

// function sum(a: number, b: number): number{
//     return a + b;
// }
//function with default values 
// function sum(a: number=12, b: number=12): number{
//     return a + b;
// }


// console.log("sum is :", sum(10, 30));
// console.log("sum is :", sum(110, 310));
// console.log("sum is :", sum());

// function greetingMessage(name: string): void{
//     console.log("hello , welcome to lebyy.com ", name);
// }

// greetingMessage("john");

function sum(a: number, b: number): number{
    return a + b;
    console.log("after return statement");
}

console.log("sum is :", sum(10, 30));


//I want to add 2 numbers
