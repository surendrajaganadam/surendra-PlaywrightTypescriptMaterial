// function add2Numbers(a: number, b: number): number {
//     return a + b;
// }

// let sumValue = (a: number, b: number): number => { return a + b; }
// let sumValue = (a: number, b: number): number => a + b; 

// console.log(sumValue(5, 10)); // Outputs: 15 

/*
let x = add2Numbers(a: number, b: number): number => {
    return a + b;
}
    cosole.log(x(5,10));

arrow function: there wont be any name to the function n even there wont any function keyword also

no need to place brases also , as sinle line is return value u no need to add return keyword also

*/


// let greetingMessage3 = (): string => "Hello, Guest!";
// console.log(greetingMessage3()); // Outputs: Hello, Guest!

// let greetingMessage3 = (): void => { console.log("Hello, Guest!"); }
// greetingMessage3(); // Outputs: Hello, Guest!

let greetingMessage3 = (name: string): void => { console.log("Hello, Guest!" +name); }
greetingMessage3("surendra"); // Outputs: Hello, Guest!