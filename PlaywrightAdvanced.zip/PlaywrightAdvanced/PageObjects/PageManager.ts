import {Page, Locator } from '@playwright/test';
import { LoginPage } from './LoginPage';
import { HomePage } from './HomePage';
import { YourCartPage } from './YourCartPage';
import { YourInfoPage } from './YourInfoPage';
import { OverviewPage } from './OverviewPage';
import { OrderConfirmationPage } from './OrderConfirmationPage';

export class PageManager {
readonly page: Page;
readonly loginPageInstance: LoginPage;
readonly homePageInstance: HomePage;
readonly yourcartPageInstance: YourCartPage;
readonly yourinfoPageInstance: YourInfoPage;
readonly overviewPageInstance: OverviewPage;
readonly orderconfimPageInstance: OrderConfirmationPage;


constructor(page: Page){
this.page=page;
this.loginPageInstance = new LoginPage(this.page);
this.homePageInstance = new HomePage(this.page);
this.yourcartPageInstance = new YourCartPage(this.page);
this.yourinfoPageInstance = new YourInfoPage(this.page);
this.overviewPageInstance = new OverviewPage(this.page);
this.orderconfimPageInstance = new OrderConfirmationPage(this.page);
}

instanceToConfirmationPage(){
return this.orderconfimPageInstance;
}

instanceToOverviewPage(){
return this.overviewPageInstance;
}

instanceToYourInfoPage(){
return this.yourinfoPageInstance;
}
instanceToYourCartPage(){
return this.yourcartPageInstance;
}

instanceToLoginPage(){
return this.loginPageInstance;
}

instanceToHomePage(){
return this.homePageInstance;
}


}