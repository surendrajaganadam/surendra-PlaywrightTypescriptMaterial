import {test} from '@playwright/test';
import { LoginPage } from '../PageObjects/LoginPage';
import { HomePage } from '../PageObjects/HomePage';
import { YourCartPage } from '../PageObjects/YourCartPage';
import { YourInfoPage } from '../PageObjects/YourInfoPage';
import { OverviewPage } from '../PageObjects/OverviewPage';
import { OrderConfirmationPage } from '../PageObjects/OrderConfirmationPage';


test('SauceDemo E2E Scenario 1', async ({page})=> {

const loginPageInstance = new LoginPage(page);
const homePageInstance = new HomePage(page);
const yourCartPageInstance = new YourCartPage(page);
const yourInfoPageInstance = new YourInfoPage(page);
const overviewPageInstance = new OverviewPage(page);
const orderConfirmationPageInstance = new OrderConfirmationPage(page);

//login to application
loginPageInstance.openSauceDemoApp();
await page.waitForTimeout(3000);
loginPageInstance.loginToApplication('standard_user', 'secret_sauce');
await page.waitForTimeout(3000);

//add items to cart
await homePageInstance.addProductToCart();

//click on checkout
await yourCartPageInstance.proceedToCheckout();

//enter details
await yourInfoPageInstance.enterYourDetails('surendra', 'jaganadam', '500018');

//place the order
await overviewPageInstance.placeTheOrder();

//validate the message , click on back to home
await orderConfirmationPageInstance.navigateToHomePage();

//logout from the application
await homePageInstance.logoutFromApplication();

//close the application
loginPageInstance.closeTheApplication();

});

test('SauceDemo E2E Scenario 2', async ({page})=> {
const loginPageInstance = new LoginPage(page);
const homePageInstance = new HomePage(page);

//login to application
loginPageInstance.openSauceDemoApp();
await page.waitForTimeout(3000);
loginPageInstance.loginToApplication('standard_user', 'secret_sauce');
await page.waitForTimeout(3000);

//logout from the application
await homePageInstance.logoutFromApplication();

});
