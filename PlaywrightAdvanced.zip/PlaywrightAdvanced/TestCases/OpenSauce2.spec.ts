import {test} from '@playwright/test';
import { PageManager } from '../PageObjects/PageManager';

test('SauceDemo E2E Scenario 2', async ({page})=> {
const pageManager = new PageManager(page);

pageManager.instanceToLoginPage().openSauceDemoApp();
pageManager.instanceToLoginPage().closeTheApplication();

});
