import {test} from '@playwright/test';
import { PageManager } from '../PageObjects/PageManager';

test('SauceDemo E2E Scenario 1', async ({page})=> {

const pm = new PageManager(page);

//login to application
pm.instanceToLoginPage().openSauceDemoApp();
await page.waitForTimeout(3000);
pm.instanceToLoginPage().loginToApplication('standard_user', 'secret_sauce');
await page.waitForTimeout(3000);

//add items to cart
await pm.instanceToHomePage().addProductToCart();

//click on checkout
await pm.instanceToYourCartPage().proceedToCheckout();

//enter details
await pm.instanceToYourInfoPage().enterYourDetails('surendra', 'jaganadam', '500018');

//place the order
await pm.instanceToOverviewPage().placeTheOrder();

//validate the message , click on back to home
await pm.instanceToConfirmationPage().navigateToHomePage();

//logout from the application
await pm.instanceToHomePage().logoutFromApplication();

//close the application
pm.instanceToLoginPage().closeTheApplication();

});
