class studentInfo4{
studentName:string;
studentID:number;
studentMarks:number;

constructor(studentName:string, studentID:number, studentMarks:number){
this.studentName = studentName;
this.studentID = studentID;
this.studentMarks = studentMarks;

}

printData(): void{
console.log(`Student Name: ${this.studentName}, Student ID: ${this.studentID}, Student Marks: ${this.studentMarks}`);
}

}

let stdent1 = new studentInfo4("John", 101, 85);
stdent1.printData();