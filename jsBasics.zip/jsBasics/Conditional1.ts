let studentAge: number = 10;

/*
syntax for if
if(condition) {
execute the logic inside the if
}

syntax for if else
if(condition) {
execute the logic inside the if
} else {
execute the logic inside the else
}

*/
//example for if block
// if(studentAge >= 18) {
//     console.log("You are eligible to vote");
// }

//example for if else blck
if(studentAge >= 18) {
    console.log("You are eligible to vote");
} else {
    console.log("You are not eligible to vote");
}

