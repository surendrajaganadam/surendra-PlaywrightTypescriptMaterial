let empSalary: number = 25000;

if(empSalary >= 20000) {
    console.log("You are eligible for bonus");
    let bonusAmount: number = empSalary * 0.5;  
      if(bonusAmount > 5000) {
        console.log("You are eligibl for share options");
        }else {
            console.log("You are not eligible for share options");
        }

}
