class StudentInfo7{
public studentName:string;

constructor(studentName:string){
this.studentName = studentName;
}

printData(): void{
console.log(`Student Name: ${this.studentName}`);
}

}

let student1 = new StudentInfo7("John");
student1.printData();