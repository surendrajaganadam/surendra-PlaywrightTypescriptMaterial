class studenInfo9{
protected studentName:string;

constructor(studentName:string){
this.studentName = studentName;

}


}

class studenInfo10 extends studenInfo9{

printData(): void{
console.log(`Student Name: ${this.studentName}`);
}

}

let student12 = new studenInfo10("John");
student12.printData();