class studentInformation {
/*
if we define a fucntion within a class we call it method
*/

printData(): void {
console.log("This is a method inside a class");
}

}

let data = new studentInformation();
data.printData();

/*
with the object we are able to access the method & properties present with that class
*/
