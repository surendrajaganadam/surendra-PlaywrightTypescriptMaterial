class Parent {
printData(): void{
console.log("I am parent class method");
}
}

class Child extends Parent {
// printData(): void{
// console.log("I am child class method");
// }
}

let childInstance = new Child();
childInstance.printData();  // it will call child class method because we have overridden the method