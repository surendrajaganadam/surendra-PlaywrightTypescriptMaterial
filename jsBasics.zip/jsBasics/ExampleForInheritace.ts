/*
Inheritnace: parent child relationship between classes
we uses extends keyword to achieve inheritnace



*/

class Animal{

displayParent():void {
console.log("I am a parent class method");
}

}

class Dog extends Animal {
displayChild():void {
console.log("I am a child class method");
}
}

let dogInstance = new Dog();
dogInstance.displayParent();
dogInstance.displayChild();
