var empID: number = 101
console.log("Employee ID: " + empID)
var empAccountBalance: number = -1000.50
console.log("Account Balance: " + empAccountBalance)

var number: number = 1000 / 0
console.log("number: " + number)

var num: number = -3 / 0
console.log("num: " + num)

var result: number = Number("abc") / 10
console.log("result: " + result)
