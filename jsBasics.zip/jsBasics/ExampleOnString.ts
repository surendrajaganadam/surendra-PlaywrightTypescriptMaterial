let inputString: string = "Hello TypeScript";
let outputString: string = "Hello JavaScript";
//get total no characters in the string
// console.log("Total no of characters: " + inputString.length);

//i want to add this is surendra text to inputString
// console.log("After concatenation: " + inputString.concat(" this is surendra"));

/*
ideally in the given string the character count will start from 0th index
which means my 1st character is of 0 index and next character is of 1st and so on
H e l l o   T y p e S c r i p t
0 1 2 3 4 5 6 7 8 9 10 11 12 13
*/

// console.log("Character at 13th index: " + inputString.charAt(13));

//i want to replace my Hello with Hi
// console.log("After replacement: " + inputString.replace("Hello", "Hi"));

//i want to convert the entire sting to lower case
// console.log("Lower case: " + inputString.toLowerCase());

//i want to convert the entire sting to upper case
// console.log("Upper case: " + inputString.toUpperCase());

//i want to split my given string into mutuple substring
// console.log("Split the string: " + inputString.split(" "));

//i want to remove the extra spaces before and after the string
// console.log("After trim: '" + inputString.trim() + "'");

//i want to check whether the given string starts with Hello or not
// console.log("Starts with Hello: " + inputString.startsWith("Hello"));

// i want to check whether the given string ends with TypeScript or not
// console.log("Ends with TypeScript: " + inputString.endsWith("TypeScript"));

//i want to check whether the given string contains TypeScript or not
console.log("Contains TypeScript: " + inputString.includes("TypeScript"));

