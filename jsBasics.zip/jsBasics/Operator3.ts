let a:number = 10;
let b:number = 20;

// let resultValue:boolean = a <= b;
// console.log("resultValue: " + resultValue);

/*
== equal to loose equality
=== equal to strict equality 

*/

// console.log("comparing a value " + (a == 10.0));
// console.log("comparing a value " + (a === 10.0));
console.log("compare null and undefined " + (null == undefined));
console.log("compare null and undefined " + (null === undefined));