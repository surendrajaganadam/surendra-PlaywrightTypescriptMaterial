// function add3(...numbers: number[]): void {
// // console.log(numbers);
// for(let num of numbers){
// console.log(num);

// }
// }
/*
if there a parameter then this rest parameter should be passed second
*/

function add3(...numbers: number[]): number {
let sum: number =0;
for(let num of numbers){
sum+= num; // sum = sum + num

}
return sum;
}

console.log(add3(1,2,3,4)); // Outputs: [ 2, 3, 4 ]
