let inputNumber: number = 20;

/* single line comment --> ideally our program with comments will be added for a redability purpose
let outputNumber: number = inputNumber + 100;
console.log("outputNumber: " + outputNumber);

let outputNumber: number = inputNumber - 10; 
console.log("outputNumber: " + outputNumber); 

let outputNumber: number = inputNumber * 5;
console.log("outputNumber: " + outputNumber);


let outputNumber: number = inputNumber / 2;
console.log("outputNumber: " + outputNumber);

let outputNumber: number = inputNumber % 2;
console.log("outputNumber: " + outputNumber);*/

let outputNumber: number = inputNumber * 2;
// outputNumber++;
// console.log("outputNumber: " + outputNumber);

outputNumber--;
console.log("outputNumber: " + outputNumber);