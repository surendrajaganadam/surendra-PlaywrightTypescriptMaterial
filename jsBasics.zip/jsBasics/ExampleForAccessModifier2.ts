class sudenInfo8{
private name:string;

constructor(name:string){
this.name = name;

}

printData(): void{
console.log(`Student Name: ${this.name}`);
}

}

let student11 = new sudenInfo8("John");
student11.printData();
