interface Vehicle {
vehicleType: string; //bike or car
noOfWheels: number; // 2 or 4
start(): void; // bike : with a kick start, car : with a button

}

class Car implements Vehicle {

vehicleType: string;
noOfWheels: number;

constructor(vehicleType: string, noOfWheels: number) {
    this.vehicleType = vehicleType;
    this.noOfWheels = noOfWheels;
}

start(): void {
    console.log("Car is started with a button");
}
}

let carInstance = new Car("car", 4);
console.log(carInstance);
carInstance.start();


class Bike implements Vehicle {

vehicleType: string;
noOfWheels: number;

constructor(vehicleType: string, noOfWheels: number) {
    this.vehicleType = vehicleType;
    this.noOfWheels = noOfWheels;
}

start(): void {
    console.log("Bike is kick started");
}
}

let bikeInstance = new Bike("bike", 2);
console.log(bikeInstance);
bikeInstance.start();