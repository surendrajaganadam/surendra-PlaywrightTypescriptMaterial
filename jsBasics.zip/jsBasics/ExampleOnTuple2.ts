// let studentInfo: [number, string] = [101, "John"];
// console.log("student info before insertion", studentInfo);

// studentInfo.push(102,"Smith");
// console.log("student info after insertion", studentInfo);

// studentInfo.pop(); // removes last element
// console.log("student info after pop", studentInfo);


// let studentData: [number, string?] = [101];
// console.log("student info before insertion", studentData);

// studentData.push(102, "Smith");
// console.log("student info after insertion", studentData);

let studentInfo: [number, string] [] = [
[101, "John"],
[102, "Smith"],
[103, "Mary"]
];

for(let student of studentInfo){
    console.log(student[0], student[1]);
}