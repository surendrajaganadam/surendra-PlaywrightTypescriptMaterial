let age:number = 25;
// let isAdult:boolean = age >=18 ? true : false;
// console.log("isAdult: " + isAdult);

// let canWatchMovie: string = age >=18 ? "Yes , you can watch the movie" : "NO, You cant watch the movie"
// console.log("canWatchMovie: " + canWatchMovie);

let firstNameValue:string = "John";

let statusValue  = typeof firstNameValue 
console.log("statusValue: " + statusValue);