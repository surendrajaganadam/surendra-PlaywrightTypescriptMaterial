/*
Anonymous function: 

function name(): return stmt {

}

var = function()
{

}

var();
*/

// let greetingMessage = function(name: string): string {
//     return "hello " + name
// }

// console.log(greetingMessage("John"))

// function sum(a: number, b?: number): number{
//     if(typeof b == "undefined"){
//         return a + 10
//     }else {
//         return a + b;

//     }
    
//     console.log("after return statement");
// }
//optional paramter should come after required parameters only
// function sum(b?: number, a: number, ): number{
//     if(typeof b == "undefined"){
//         return a + 10
//     }else {
//         return a + b;

//     }
    
//     console.log("after return statement");
// }

// console.log("sum is :", sum(10, 30));
// console.log("sum is :", sum(10));
// 
/*
optional parameters : we may or may not pass these values to a function

? symbol after the parameter name : which u TS consider as an optional paramter
*/


/*
function overloading::

*/