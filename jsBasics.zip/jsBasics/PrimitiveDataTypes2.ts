var empFirstName: string = "Surendra";
var empLastName: string = 'Jaganadam';
console.log("employee name: " + empFirstName + " " + empLastName);

var isLoggedIn: boolean = false;
console.log("isLoggedIn: " + isLoggedIn);

let itemCount: undefined;
console.log("itemCount is: " + itemCount);

var empLastLogin: null;
empLastLogin = null; //variable value must be set explicility
console.log("empLastLogin is: " + empLastLogin);

