// function exampleForVar1(){
// var a = 10;
// if(a === 10){
//     var a = 20;
//     console.log(a);
// }
// }

// exampleForVar1(); //20

function exampleForLet1(){

if(true){
    let a = 20;
    console.log(a);
//     let a = 30;
//     console.log(a);
}

// if(a == 20){
// console.log(a);
// }
}

exampleForLet1(); //20