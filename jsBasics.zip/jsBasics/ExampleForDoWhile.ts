

/*
do
{
logic inside the do block
}while(condition);

*/


// let j:number = 1;
// do{
//     console.log("value of j: " + j);
//     j++;
// }while(j <= 10);

// let j:number = 1;
// do{
//     if(j % 2 == 0){
//         console.log("Even number: " + j);
//     }
//     j++;
// }while(j <= 10);

// let j:number = 1;
// do{
//     if(j % 2 != 0){
//         console.log("Odd number: " + j);
//     }
//     j++;
// }while(j <= 10);