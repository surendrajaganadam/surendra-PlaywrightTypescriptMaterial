import {test} from '@playwright/test';

test.only('Login to saucedemo application', async ({page}, testInfo)=> {
if(testInfo.project.name === 'surendra1234'){
//perform those clickc operateions which are specific to this device
}
await page.goto('https://www.saucedemo.com/');
await page.pause();
await page.locator('#user-name').fill('standard_user');
await page.locator('#password').fill('secret_sauce');
await page.locator('#login-button').click();




})


