import {test} from '@playwright/test';
import {expect} from '@playwright/test';

test('Launch application', async ({page})=> {

await page.goto('https://www.saucedemo.com/');
// await page.pause();
const loginBtnLocator = await page.locator('#login-button')
await expect(loginBtnLocator).toHaveText('surendra');


})

