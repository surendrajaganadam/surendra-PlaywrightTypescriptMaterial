import {test} from '@playwright/test';

test('Get 1st row n 1st column value n print it', async ({page})=> {
await page.goto('https://www.w3schools.com/html/html_tables.asp');
await page.pause();

const tableRows = await page.locator('#customers').getByRole('row');

for(let i=1; i< await tableRows.count(); i++){
const row = await tableRows.nth(i).locator('//td[2]');
const rowText = await row.textContent();
console.log(rowText);
}

for(const row of await tableRows.all()){
const rowText = await row.textContent();
console.log(rowText);
}

await page.close();

});


