import {test} from '@playwright/test';
import {expect} from '@playwright/test';




test('Login to saucedemo application', async ({page}, testInfo)=> {

await page.goto('/');
if(testInfo.retry){
console.log(`The test is retrying for the ${testInfo.retry} time`);
console.log(`The test is retrying for the ${testInfo.title} time`);
}
// await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
const loginBtnLocator = await page.locator('#login-button')
await expect(loginBtnLocator).toHaveText('Surendra');

});


