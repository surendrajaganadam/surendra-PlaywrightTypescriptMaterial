import { test, expect } from '@playwright/test';


test('Handle dropdown 1', async ({ page }) => {

  await page.goto('https://www.salesforce.com/form/developer-signup/?d=pb');
  await page.pause();

  // await page.getByRole('combobox').selectOption('Afghanistan');
  // await page.getByLabel('Country/Region').selectOption('Algeria');
  // await page.locator('//select[@name="CompanyCountry"]').selectOption('Angola');
  // await page.locator('//select[@name="CompanyCountry"]').selectOption({index: 4});
  // await page.locator('//select[@name="CompanyCountry"]').selectOption({value: 'BH'});

  // const ddOptions = await page.locator('//select[@name="CompanyCountry"]').getByRole('option').allTextContents();
  // await expect(ddOptions.length).toBe(230);
  // await expect(ddOptions).toContain('India');

  // for(const values of ddOptions){
  //   console.log(values);
  // }

const ddOptions = await page.locator('//select[@name="CompanyCountry"]').getByRole('option');  
await expect(ddOptions).toHaveCount(230);

for(const values of await ddOptions.allTextContents()){
  console.log(values);
}



  await page.close();
});
