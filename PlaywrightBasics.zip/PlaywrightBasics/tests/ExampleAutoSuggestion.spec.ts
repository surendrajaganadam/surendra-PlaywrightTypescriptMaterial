import {test} from '@playwright/test';

test('Auto Suggestions', async ({page})=> {
await page.goto('https://www.bing.com');
await page.pause();

// await page.locator('#sb_form_q').fill('Playwright');
await page.getByRole('textbox').fill('Playwright');

// const values = await page.locator('//div[@class="sa_tm"]')
const values = await page.locator('#sa_sug_block').locator('//div[@class="sa_tm"]')

for(const value of await values.all()){
const valueText = await value.textContent();
console.log(valueText);
}
await page.close();

});


