import {test} from '@playwright/test';

test.beforeEach(async ({page})=> {
console.log("This is before each hook")
})

test.afterEach(async ({page})=> {
console.log("This is after each hook")
})

test('login to saucedemo with valid crdentails', async ({page})=> {
console.log(" login to saucedemo with valid crdentails")
})

test('login to saucedemo with invalid crdentails', async ({page})=> {
console.log(" login to saucedemo with invalid crdentails")
})