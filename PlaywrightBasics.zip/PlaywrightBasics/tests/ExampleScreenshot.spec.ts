import {test} from '@playwright/test';

test('Capture Screenshot', async ({page})=> {
await page.goto('https://www.amazon.com/');
await page.pause();

// await page.screenshot({ path: 'tests/data/screenshot.png' });
// await page.screenshot({ path: 'tests/data/screenshot_' + Date.now() + '.png' });

// await page.screenshot({ path: 'tests/data/screenshot_' + Date.now() + '.png',  fullPage: true });

await page.getByRole('textbox').screenshot({ path: 'tests/data/screenshot_' + Date.now() + '.png' });
await page.close();
})


