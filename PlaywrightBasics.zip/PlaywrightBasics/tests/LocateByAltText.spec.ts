import { test } from '@playwright/test';

test('Locate using Alt text', async ({page})=> {
await page.goto('https://www.bing.com/');

await page.getByAltText('© The Daily Jagran').click();

await page.close();

});


test('Locate using data test ID', async ({page})=> {
await page.goto('https://www.emirates.com/in/english/book/?utm_source=');

await page.locator('#onetrust-accept-btn-handler').click();

await page.getByTestId('combobox_Departure airport').click();

// await page.close();

});