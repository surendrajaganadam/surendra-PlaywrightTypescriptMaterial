import {test} from '@playwright/test';
import {expect} from '@playwright/test';

// test('Login to saucedemo application', async ({page})=> {
// const numberValue = 10;//may be u will be getting some valiue from the browser
// expect.soft(numberValue).toEqual(11); // urgoing to compare it with the desired value

// await page.goto('https://www.saucedemo.com/');

// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();

// await page.close();
// })


// test('Login to saucedemo application', async ({page})=> {
// await page.goto('https://www.saucedemo.com/');

// // await expect(page).toHaveURL('https://www.surendrademo.com/');
// // await expect(page).toHaveTitle('sirendra');

// await page.close();

// })

// test('Login to saucedemo application', async ({page})=> {
// await page.goto('https://www.saucedemo.com/');

// const usernameTextField = await page.locator('#user-name');
// await expect(usernameTextField).toBeVisible();

// await expect(page.locator('#user-name')).toBeVisible();

// await expect(usernameTextField).toBeHidden();

// await expect(usernameTextField).toBeEnabled();
// await expect(usernameTextField).toBeDisabled();


// await page.close();

// })

test('Login to saucedemo application', async ({page})=> {
await page.goto('https://www.saucedemo.com/');

const usernameTextField = await page.locator('#user-name');
// await expect(usernameTextField).toHaveCount(1);

// await expect(usernameTextField).toHaveAttribute('placeholder','Username');

const loginButton = await page.locator('#login-button');
await expect(loginButton).toHaveText('Login');
await expect(loginButton).not.toHaveText('surendra');

await page.close();

})




