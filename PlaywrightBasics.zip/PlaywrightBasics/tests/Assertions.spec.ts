import {test} from '@playwright/test';
import {expect} from '@playwright/test';

test('Login to saucedemo application', async ({page})=> {
const numberValue = 10;//may be u will be getting some valiue from the browser
expect(numberValue).toEqual(10); // urgoing to compare it with the desired value

await page.goto('https://www.saucedemo.com/');

// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();

await page.close();
})


// test('Login to saucedemo application', async ({page})=> {
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// // await page.locator('#user-name').fill('standard_user');
// // await page.locator('#password').fill('secret_sauce');
// const loginBtnLocator = await page.locator('#login-button')
// await expect(loginBtnLocator).toHaveText('Surendra');

// })


