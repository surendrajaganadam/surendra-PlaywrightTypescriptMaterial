import {test} from '@playwright/test';

test('Handle tooltip', async ({page})=> {
await page.goto('https://jqueryui.com/droppable/');
await page.pause();

const frame1 = await page.frameLocator('//iframe[@class="demo-frame"]')
const tooltipvalue = await frame1.locator('#age').getAttribute('title')
console.log(tooltipvalue);



await page.close();


})

