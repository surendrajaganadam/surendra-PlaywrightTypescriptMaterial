import { test } from '@playwright/test';

test('Locate using label', async ({page})=> {
await page.goto('https://www.salesforce.com/uk/form/signup/sales-ee/');

await page.getByLabel(' First Name ').fill('surendra');

await page.close();

});


test('Locate using PlaceHolder', async ({page})=> {
await page.goto('https://www.saucedemo.com/');

await page.getByPlaceholder('Username').fill('surendra');


await page.close();

});
