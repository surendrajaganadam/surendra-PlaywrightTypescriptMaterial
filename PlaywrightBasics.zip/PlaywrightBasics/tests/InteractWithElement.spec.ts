import {test} from '@playwright/test';

test('Interact with username and password', async ({page})=> {
await page.goto('https://www.saucedemo.com/');
//identify an element using its id attribute
page.locator('#user-name')

//idenitfy using tagname
page.locator('input')

//ideitfy using classname
page.locator('.input_error')
page.locator('.form_input')

//idetify usuing its full classname attribute
page.locator('[class="input_error form_input"]')

//idenitfy using attribute with placeholder value
page.locator('[placeholder="Username"]')

//idenitfy using multiple attributes
page.locator('#user-name.form_input[placeholder="Username"]')

//ideify using text
page.locator('text=Login')
page.locator('has-text("Login")')
page.locator('text-is("Login")')

})