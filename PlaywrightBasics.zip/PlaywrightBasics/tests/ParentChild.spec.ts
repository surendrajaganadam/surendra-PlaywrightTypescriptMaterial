import { test } from '@playwright/test';

test('Locate using parent and child', async ({page})=> {
await page.goto('https://www.makemytrip.com/');
await page.pause();

const flightLocator = page.locator('[class="makeFlex font12 headerIconsGap"]').locator('[class="menu_Flights"]').getByRole('link',{name:"Flights"});

await flightLocator.click();
// await page.locator('ul', {hasText: 'Flights'}).getByRole('link', {name: 'Visa'}).click();

await page.close();

});