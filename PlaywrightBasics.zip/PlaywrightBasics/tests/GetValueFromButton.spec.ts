import {test} from '@playwright/test';
import {expect} from '@playwright/test';





// test('Handle button text', async ({page})=> {
// await page.goto('https://www.makemytrip.com/');
// await page.pause();
// await page.locator('section').filter({ hasText: 'Personal AccountMyBiz Account' }).locator('span').first().click();
// const textValue = await page.getByRole('button', {name: 'Flight Tracker'}).textContent();
// console.log(textValue)

// /*
// inputvalue() : will get the value from the text field
// textContent() : is used to get the text from the specficed button
// */

// await page.close();


// })

test('Handle button text', async ({page})=> {
await page.goto('https://www.makemytrip.com/');
await page.pause();
await page.locator('section').filter({ hasText: 'Personal AccountMyBiz Account' }).locator('span').first().click();
// const textValue = await page.getByRole('button', {name: 'Flight Tracker'}).textContent();
// console.log(textValue)

const values = await page.locator('//button').allTextContents();
console.log(values)

/*
inputvalue() : will get the value from the text field
textContent() : is used to get the text from the specficed button
allTextContents() : is used to get text from all the button in the webpage

*/

await page.close();


})


