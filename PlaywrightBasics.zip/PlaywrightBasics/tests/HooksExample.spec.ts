import {test} from '@playwright/test';

test.beforeEach(async ({page})=> {
await page.goto('https://www.saucedemo.com/');
})

test.afterEach(async ({page})=> {
await page.close();
})



test('Login to saucedemo application with valid credentials', async ({page})=> {

// await page.pause();
await page.locator('#user-name').fill('standard_user');
await page.locator('#password').fill('secret_sauce');
await page.locator('#login-button').click();


})

test('login with invalid credentails', async ({page})=> {

// await page.pause();
await page.locator('#user-name').fill('standardr');
await page.locator('#password').fill('secrete');
await page.locator('#login-button').click();


})

/*
pre condition here : open the saucedemo application
post condition here : close the browser

hooks r sying that istead of defining pre and post condition in each test we can define it once in the hooks file and call it in the test file
*/
