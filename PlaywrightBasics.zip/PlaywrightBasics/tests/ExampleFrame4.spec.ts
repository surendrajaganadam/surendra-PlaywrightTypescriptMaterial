import {test} from '@playwright/test';

// test('Handle datepicker', async ({page})=> {
// await page.goto('https://jqueryui.com/datepicker/');
// await page.pause();

// const frame1 = await page.frameLocator('//iframe[@class="demo-frame"]')

// await frame1.locator('#datepicker').click();
// // await frame1.locator('//a[text()="15"]').click();
// await frame1.locator('//span[@class="ui-icon ui-icon-circle-triangle-e"]').click();
// await frame1.locator(':text-is("15")').click();


// await page.close();


// })

test('Handle datepicker', async ({page})=> {
await page.goto('https://jqueryui.com/datepicker/');
await page.pause();

const frame1 = await page.frameLocator('//iframe[@class="demo-frame"]')

await frame1.locator('#datepicker').click();
await frame1.locator('(//td[@class=" ui-datepicker-days-cell-over  ui-datepicker-today"]//following::td[@data-handler="selectDay"])[1]').click();

await page.close();


})


