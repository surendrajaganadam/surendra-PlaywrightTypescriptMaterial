import {test} from '@playwright/test';

test('Locate by its Text', async ({page})=> {
await page.goto('https://www.salesforce.com/uk/form/signup/sales-ee/');

await page.getByText('NEXT').click();


await page.close();

})

test('Locate by its Title', async ({page})=> {
await page.goto('https://jqueryui.com/tooltip/');

await page.getByTitle('jQuery UI').first().click();


// await page.close();

})



