import {test} from '@playwright/test';

// test('Login to saucedemo application with valid credentails', {tag: '@story1'},async ({page})=> {
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();


// })

// test('Login to saucedemo application with invalid username', {tag: ['@story1','@reg']}, async ({page})=> {
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// await page.locator('#user-name').fill('standard');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();


// })

// test('Login to saucedemo application with invalid password', {tag: ['@story1','@smoke']}, async ({page})=> {
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('1245');
// await page.locator('#login-button').click();

// })

test.describe('group of tests', {tag: '@reg'}, ()=> {

test('Login to saucedemo application', async ({page})=> {
await page.goto('https://www.saucedemo.com/');
// await page.pause();

})

test('Login to bing application', async ({page})=> {
await page.goto('https://www.bing.com/');
// await page.pause();

})


})

