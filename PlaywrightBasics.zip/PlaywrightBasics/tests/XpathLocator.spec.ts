import {test} from '@playwright/test';

test('Example on xpath locator', async ({page})=> {
await page.goto('https://www.makemytrip.com/');
await page.pause();
// await page.locator('//span[@class="chNavIcon appendBottom2 chSprite chFlights active"]').click();
await page.getByRole('button').filter({hasText: "Flight Tracker" }).click();
})