import { test, expect } from '@playwright/test';

test('Handle Radio Buttons', async ({ page }) => {

  await page.goto('https://www.bing.com/account/general?ru=');
  await page.pause();

  await page.getByLabel('Strict').check();
//   await page.getByRole('radio', { name: 'Moderate' }).check();
//   await page.locator('#adlt_set_off').check();
  await expect(await page.getByLabel('Strict')).toBeChecked();
//   await expect(await page.getByLabel('Moderate').isChecked()).toBeTruthy();
  await expect(await page.getByLabel('Moderate').isChecked()).toBeFalsy();




  /*

  1. getBylabel
  2. getByRole : radio + name
  3. locator


  */


 
  await page.close();
});