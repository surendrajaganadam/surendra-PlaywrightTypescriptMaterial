import {test} from '@playwright/test';
import {expect} from '@playwright/test';

test('Login to saucedemo application', async ({page})=> {
await page.goto('https://the-internet.herokuapp.com/javascript_alerts');
await page.pause();

//dailog handler
page.on('dialog', async dialog => { 
   console.log(dialog.message());
   console.log(dialog.type());
expect(dialog.message()).toBe('I am a JS Confirm');
expect(dialog.type()).toBe('confirm');
    await dialog.accept(); //ok button
    // await dialog.dismiss(); //cancel button
});

await page.locator('//button[text()="Click for JS Confirm"]').click();


await page.close();

})


