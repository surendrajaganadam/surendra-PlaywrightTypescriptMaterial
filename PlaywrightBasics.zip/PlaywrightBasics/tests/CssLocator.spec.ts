import {test} from '@playwright/test';

test('example for css selectors', async ({page})=> {
await page.goto('https://www.makemytrip.com/');
await page.pause();
// await page.locator('css=button:visible').nth(3).click();
// await page.locator('css=button:visible').locator('font:has-text("Flight Tracker")').click();
// await page.locator('css=button:visible').locator('font:has-text("flight tracker")').click();
// await page.locator('css=button:visible').locator('font:text-is("flight ")').click();
// await page.locator('css=button:visible').locator('font:text("flight ")').click();
// await page.locator('css=button:visible').locator(':is(font:text("Flight Tracker"), span:text("Create Account"))').click();
await page.locator('button:has(div.fisWidgetContent)').click();

})

/*
with the given locator if there are multiple elements r there then we can use below 3 methods:
1. first() - it will select the first element from the list of elements
2. last() - it will select the last element from the list of elements
3. nth(index) - it will select the element based on the index provided in the nth method
0 --> 1st value
1 --> 2nd value
2 --> 3rd value
index starts from 0

*/