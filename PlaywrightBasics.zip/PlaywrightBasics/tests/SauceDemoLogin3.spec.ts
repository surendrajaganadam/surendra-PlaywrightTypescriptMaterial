import {test, expect} from '@playwright/test';

test.only('Login to saucedemo application', async ({page})=> {

await page.goto('https://www.saucedemo.com/');

await page.locator('#user-name').fill('');
 await expect(page).toHaveScreenshot({ maxDiffPixels: 250 });

await page.close();
})
