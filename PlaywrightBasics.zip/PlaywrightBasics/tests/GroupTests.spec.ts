import {test} from '@playwright/test';

test.describe('Saucedemo login test cases group', ()=> {

test('Login to saucedemo application', async ({page})=> {
await page.goto('https://www.saucedemo.com/');
// await page.pause();
await page.locator('#user-name').fill('standard_user');
await page.locator('#password').fill('secret_sauce');
await page.locator('#login-button').click();


})

test('login with invalid credentails', async ({page})=> {
await page.goto('https://www.saucedemo.com/');
// await page.pause();
await page.locator('#user-name').fill('standardr');
await page.locator('#password').fill('secrete');
await page.locator('#login-button').click();


})

})


