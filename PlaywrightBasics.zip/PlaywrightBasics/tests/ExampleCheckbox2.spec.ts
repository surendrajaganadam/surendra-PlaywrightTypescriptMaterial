import { test, expect } from '@playwright/test';

test('Handle checkboxes', async ({ page }) => {

  await page.goto('https://www.bing.com/account/general?ru=');
  await page.pause();

  const checkboxes = await page.getByRole('checkbox');

  for(const checkbox of await checkboxes.all()){
    await checkbox.uncheck();
    await expect(checkbox).not.toBeChecked();
  }
  

  await page.close();
});