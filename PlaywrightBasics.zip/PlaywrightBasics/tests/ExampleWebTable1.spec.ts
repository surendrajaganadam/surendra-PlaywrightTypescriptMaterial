import {test} from '@playwright/test';

test('Get 1st row n 1st column value n print it', async ({page})=> {
await page.goto('https://www.w3schools.com/html/html_tables.asp');
await page.pause();

const tableRows = await page.locator('#customers').getByRole('row');

const value1 = await tableRows.nth(1).locator('//td[1]').innerText()
console.log(value1);

const value2 = await tableRows.nth(1).locator('//td[1]').textContent();
console.log(value2);



await page.close();

});


