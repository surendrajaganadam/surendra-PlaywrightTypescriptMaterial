import {test} from '@playwright/test';
import {expect} from '@playwright/test';




// test('verify autowating 1', async ({page})=> {

// await page.goto('http://uitestingplayground.com/ajax');
// await page.locator('#ajaxButton').click();
// await page.waitForTimeout(16000); //hardcode time value
// await page.locator('.bg-success').click();

// await page.close();
// });

// test('verify autowating 2', async ({page})=> {

// await page.goto('http://uitestingplayground.com/ajax');
// await page.locator('#ajaxButton').click();
// // await page.waitForSelector('.bg-success');
// // await page.locator('.bg-success').waitFor({state:'visible'})
// await page.locator('.bg-success').click();

// await page.close();
// });

// test('verify autowating 3', async ({page})=> {

// await page.goto('http://uitestingplayground.com/ajax');
// await page.locator('#ajaxButton').click();

// // const value = await page.locator('.bg-success').textContent();
// // console.log(value);

// const value = await page.locator('.bg-success').allTextContents();
// // console.log(value);
// await expect(page.locator('.bg-success')).toHaveText('Data loaded with AJAX get request.', {timeout: 20000});



// await page.close();
// });



test('verify autowating 4', async ({page})=> {

await page.goto('https://www.saucedemo.com/');
await page.locator('#user-name').fill('standard_user');
await page.locator('#password').fill('secret_sauce');
await page.locator('#login-button').click();

await page.waitForURL('https://www.saucedemo.com/surendra');



await page.close();
});



test('verify autowating 5', async ({page})=> {
// test.setTimeout(20000);
test.slow(); // 3 times of timeout value for this test 
await page.goto('http://uitestingplayground.com/ajax');
// await page.locator('#ajaxButton').click({timeout: 20000 });

const value = await page.locator('.bg-success').allTextContents();
// console.log(value);
await expect(page.locator('.bg-success')).toHaveText('Data loaded with AJAX get request.', {timeout: 20000});



await page.close();
});