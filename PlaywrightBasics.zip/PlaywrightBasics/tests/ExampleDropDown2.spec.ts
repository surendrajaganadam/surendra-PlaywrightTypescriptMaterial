import { test, expect } from '@playwright/test';


// test('Handle dropdown 2', async ({ page }) => {

//   await page.goto('https://testpages.herokuapp.com/styled/basic-html-form-test.html');
//   await page.pause();

//   // await page.getByRole('listbox').selectOption(['Selection Item 1','Selection Item 2']);
//   await page.locator('//select[@multiple="multiple"]').selectOption(['Selection Item 1','Selection Item 2']);

//   const ddOptions = page.locator('//select[@multiple="multiple"]').getByRole('option').allTextContents();

//   for(const values of await ddOptions){
//     console.log(values);
//   }

//   await page.close();
// });


test('Handle dropdown 2', async ({ page }) => {

  await page.goto('https://getbootstrap.com/docs/5.3/components/dropdowns/');
  await page.pause();

  await page.locator('(//button[@class="btn btn-secondary dropdown-toggle"])[1]').click();
  
  await page.locator('(//a[text()="Another action"])[1]').click();

  await page.close();
});
