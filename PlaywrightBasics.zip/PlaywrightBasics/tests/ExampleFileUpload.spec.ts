import {test} from '@playwright/test';

test('Upload 1 file', async ({page})=> {
await page.goto('https://the-internet.herokuapp.com/upload');
await page.pause();
await page.locator('#file-upload').setInputFiles('tests/image1.pdf');
// await page.locator('#file-submit').click();

await page.close();


});


test('Upload 2 files', async ({page})=> {
await page.goto('https://www.file.io/');
await page.pause();
await page.locator('#select-files-input').setInputFiles(['tests/image1.pdf','tests/image2.pdf']);
// await page.locator('#file-submit').click();

await page.close();


});

test.only('delete uploaded 1 file', async ({page})=> {
await page.goto('https://the-internet.herokuapp.com/upload');
await page.pause();
await page.locator('#file-upload').setInputFiles('tests/image1.pdf');
await page.locator('#file-upload').setInputFiles([]);

await page.close();


});



