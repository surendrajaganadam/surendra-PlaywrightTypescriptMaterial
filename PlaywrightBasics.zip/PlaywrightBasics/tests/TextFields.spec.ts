import {test} from '@playwright/test';
import {expect} from '@playwright/test';




// test('Handle text fields', async ({page})=> {
// await page.goto('https://www.saucedemo.com/');
// await page.pause();
// await expect(await page.locator('#user-name')).toBeVisible();
// await expect(await page.locator('#user-name')).toBeEnabled();
// await expect(await page.locator('#user-name')).toBeEmpty(); //checks whether that filed is empty or not
// await expect(await page.locator('#user-name')).toBeEditable(); //checks whether we can edit a value into that field or not

// await page.locator('#user-name').fill('surendra');
// await page.locator('#user-name').clear();


// await page.close();


// })



// test('Handle text fields', async ({page})=> {
// await page.goto('https://www.saucedemo.com/');
// await page.pause();
// await page.locator('#user-name').fill('surendra');
// await page.locator('#user-name').clear();

// await page.getByRole('textbox', {name: 'Username'}).fill("jaganadam");
// // await page.getByRole('textbox', {name: 'Username'}).clear();
// const inputValue = await page.getByRole('textbox', {name: 'Username'}).inputValue();
// console.log(inputValue)

// /*
// inputvalue() : will get the value from the text field
// */

// await page.close();


// })

test('Handle text fields', async ({page})=> {
await page.goto('https://www.salesforce.com/form/developer-signup/?d=pb');
await page.pause();

await page.getByLabel('First name').fill('surendra');
await page.getByLabel('Last name').fill('jaganadam');
await page.getByLabel('Job title').fill('QA');
await page.getByLabel('Work email').fill('surendra.jaganadam@example.com');

})