import {test} from '@playwright/test';

test('Handle frame 1', async ({page})=> {
await page.goto('https://jqueryui.com/tooltip/');
await page.pause();

const frame1 = await page.frameLocator('//iframe[@class="demo-frame"]')
// await frame1.locator('#age').fill('25');


// const frame1 = await page.frame({url: 'https://jqueryui.com/resources/demos/tooltip/default.html'})
// await frame1?.locator('#age').fill('24');

await page.close();


})

// test('Nested  frame 2', async ({page})=> {
// await page.goto('https://ui.vision/demo/webtest/frames/');
// await page.pause();


// const frame1 = await page.frame({url: 'https://ui.vision/demo/webtest/frames/frame_3.html'})
// const childFrames = await frame1?.childFrames();
// await childFrames?.at(0)?.locator('//*[@id="i6"]/div[3]/div').check();

// await page.close();


// })


