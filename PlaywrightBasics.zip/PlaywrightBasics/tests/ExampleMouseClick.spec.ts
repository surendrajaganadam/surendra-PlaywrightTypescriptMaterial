import {test} from '@playwright/test';

test('Double click operation', async ({page})=> {
await page.goto('https://www.saucedemo.com/');
await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').dblclick();

// await page.locator('#login-button').click({ button: 'right' });

// await page.locator('#login-button').click({ position: { x: 0, y: 0 } });
// await page.locator('#login-button').click({ force: true });

// await page.locator('#user-name').pressSequentially('surendra');

// await page.locator('#user-name').pressSequentially('surendra', {delay: 400});

await page.locator('#user-name').press('$');

await page.close();

});



// test('Mouse hover', async ({page})=> {
// await page.goto('https://www.emirates.com/in/english/book/?utm_source=');
// await page.pause();


// await page.locator('(//*[text()="About booking online"])[1]').hover();

// await page.close();

// });

