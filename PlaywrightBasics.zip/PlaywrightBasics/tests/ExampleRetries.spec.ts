import {test} from '@playwright/test';
import {expect} from '@playwright/test';

test.only('Am checking retry example', async ({page}, testInfo)=> {

if(testInfo.retry){
console.log(`The test is retrying for the ${testInfo.retry} time`);
console.log(`The test is retrying for the ${testInfo.title} time`);
}
await page.goto('https://www.saucedemo.com/');
// await page.pause();
const loginBtnLocator = await page.locator('#login-button')
await expect(loginBtnLocator).toHaveText('Surendra');

})

/*
fom promise:
await 

if await is there then we need to dwfine that test as an async function

*/