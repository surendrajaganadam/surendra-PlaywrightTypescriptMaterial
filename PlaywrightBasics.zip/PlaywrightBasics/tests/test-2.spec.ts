import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  // Recording...
  await page.goto('https://www.makemytrip.com/');
  await page.getByRole('textbox', { name: 'Enter Mobile Number', exact: true }).click();
  await page.getByRole('textbox', { name: 'Enter Mobile Number', exact: true }).fill('9618817771');
  await page.locator('section').filter({ hasText: 'Personal AccountMyBiz Account' }).locator('span').first().click();
});