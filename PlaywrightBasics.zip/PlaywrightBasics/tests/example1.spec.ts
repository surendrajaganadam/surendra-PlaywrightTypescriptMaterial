import { test, expect, chromium } from '@playwright/test';
import { text } from 'stream/consumers';

// test.skip('has title', async ({ page }) => {
//   await page.goto('https://playwright.dev/');

//   // Expect a title "to contain" a substring.
//   await expect(page).toHaveTitle(/surendre/);
// });

// test('get started link', async ({ page }) => {
//   await page.goto('https://getbootstrap.com/docs/5.3/components/dropdowns/');

//   await page.pause();

//   // await page.getByRole('listitem').selectOption('Action')
//   await page.locator('(//button[@class="btn btn-secondary dropdown-toggle"])[1]').click();
//   await page.locator('(//a[@class="dropdown-item" and contains(text(),"Action")])[1]').click();

// });

test('Login to saucedemo application', async ({})=> {
const browser = await chromium.launch();
const context = await browser.newContext();
const page = await context.newPage();
await page.goto('https://www.hdfc.com/');

const pagePromise = context.waitForEvent('page');
await page.locator('(//a[text()="Blogs"])[1]').click();
const newPage = await pagePromise;

await newPage.locator('#close-disclaimer').click();

await page.close();


})

