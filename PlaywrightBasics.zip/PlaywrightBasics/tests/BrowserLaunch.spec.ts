import {test} from '@playwright/test';
import {expect} from '@playwright/test';

test.only('open saucedemo', async ({page}, testInfo)=> {

await page.goto('https://www.saucedemo.com/');
// await page.pause();
const loginBtnLocator = await page.locator('#login-button')
await expect(loginBtnLocator).toHaveText('Surendra');

})

/*
fom promise:
await 

if await is there then we need to dwfine that test as an async function

*/