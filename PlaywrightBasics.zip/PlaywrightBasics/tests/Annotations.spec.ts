import {test} from '@playwright/test';

test('Login to saucedemo application', async ({page})=> {
test.slow();
await page.goto('https://www.saucedemo.com/');
// await page.pause();
await page.locator('#user-name').fill('standard_user');
await page.locator('#password').fill('secret_sauce');
await page.locator('#login-button').click();


})

// test.fail('Login to saucedemo application', async ({page})=> {
// test.slow();
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();


// })

// test.skip('Login to saucedemo application', async ({page})=> {
// test.slow();
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();


// })

// test.fixme('Login to saucedemo application', async ({page})=> {
// test.slow();
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();


// })

// test.only('Login to saucedemo application', async ({page})=> {
// test.slow();
// await page.goto('https://www.saucedemo.com/');
// // await page.pause();
// await page.locator('#user-name').fill('standard_user');
// await page.locator('#password').fill('secret_sauce');
// await page.locator('#login-button').click();


// })