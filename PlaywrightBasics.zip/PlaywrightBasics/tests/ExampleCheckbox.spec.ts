import { test, expect } from '@playwright/test';

// test('Handle checkboxes', async ({ page }) => {

//   await page.goto('https://www.bing.com/account/general?ru=');
//   await page.pause();

//   //below cmd will uncheck the search suggestion checkbox using label command
//   await page.getByLabel('See search suggestions as you type').uncheck();
//   //i want to check it back using getByRole
//   await page.getByRole('checkbox', { name: 'See search suggestions as you type' }).check();
//   //i want to uncheck it back using locator
//   await page.locator('enAS').check();
  

//   /*
//   check : used to check the checkbox
//   uncheck : used to uncheck the checkbox
//   isChecked : used to verify whether the checkbox is checked or not (true/false)

//   Ways to locate checkbox:
//   1. getBylabel
//   2. getByRole : radio + name
//   3. locator


//   */


 
//   await page.close();
// });


test('Handle checkboxes', async ({ page }) => {

  await page.goto('https://www.bing.com/account/general?ru=');
  await page.pause();

  // await page.locator('enAS').check();
  await page.check('#enAS');
  await page.fill('#username', 'admin');
  

 
  await page.close();
});
